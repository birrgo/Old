package com.example.AsyncTask;

import android.os.AsyncTask;

import com.example.interfaces.ProfileListener;
import com.example.utils.Constant;
import com.example.utils.JsonUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import okhttp3.RequestBody;

public class LoadProfile extends AsyncTask<String, String, String> {

    RequestBody requestBody;
    ProfileListener profileListener;
    boolean is_reporter = false;
    String success = "0", user_id = "", user_name = "", email = "", phone = "", image = "";

    public LoadProfile(ProfileListener profileListener, RequestBody requestBody) {
        this.profileListener = profileListener;
        this.requestBody = requestBody;
    }

    @Override
    protected void onPreExecute() {
        profileListener.onStart();
        super.onPreExecute();
    }

    @Override
    protected String doInBackground(String... strings) {
        try {
            String json = JsonUtils.okhttpPost(Constant.SERVER_URL, requestBody);
            JSONObject mainJson = new JSONObject(json);
            JSONArray jsonArray = mainJson.getJSONArray(Constant.TAG_ROOT);

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject c = jsonArray.getJSONObject(i);

                success = c.getString("success");
                user_id = c.getString("user_id");
                user_name = c.getString("name");
                email = c.getString("email");
                phone = c.getString("phone");
                image = c.getString("user_profile");
                is_reporter = c.getBoolean("is_reporter");
            }
            return "1";
        } catch (Exception e) {
            e.printStackTrace();
            return "0";
        }
    }

    @Override
    protected void onPostExecute(String s) {
        profileListener.onEnd(s, success, "", user_name, email, phone, image, is_reporter);
        super.onPostExecute(s);
    }
}