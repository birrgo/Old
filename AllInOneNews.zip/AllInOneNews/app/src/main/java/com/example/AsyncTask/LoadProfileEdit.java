package com.example.AsyncTask;

import android.os.AsyncTask;

import com.example.interfaces.ProfileListener;
import com.example.utils.Constant;
import com.example.utils.JsonUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import okhttp3.RequestBody;

public class LoadProfileEdit extends AsyncTask<String, String, String> {

    private RequestBody requestBody;
    private ProfileListener profileListener;
    private String success = "0", message = "", profileImage = "";

    public LoadProfileEdit(ProfileListener profileListener, RequestBody requestBody) {
        this.profileListener = profileListener;
        this.requestBody = requestBody;
    }

    @Override
    protected void onPreExecute() {
        profileListener.onStart();
        super.onPreExecute();
    }

    @Override
    protected String doInBackground(String... strings) {
        try {
            String json = JsonUtils.okhttpPost(Constant.SERVER_URL, requestBody);
            JSONObject mainJson = new JSONObject(json);
            JSONArray jsonArray = mainJson.getJSONArray(Constant.TAG_ROOT);

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject c = jsonArray.getJSONObject(i);

                success = c.getString("success");
                message = c.getString(Constant.TAG_MSG);

                if(c.has("user_profile")) {
                    profileImage = c.getString("user_profile");
                }
            }
            return "1";
        } catch (Exception e) {
            e.printStackTrace();
            return "0";
        }
    }

    @Override
    protected void onPostExecute(String s) {
        profileListener.onEnd(s, success, message, "","","",profileImage, false);
        super.onPostExecute(s);
    }
}