package com.example.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.makeramen.roundedimageview.RoundedImageView;
import com.squareup.picasso.Picasso;
import com.example.allinonenewsapp.R;
import com.example.interfaces.ClickListener;
import com.example.item.ItemComment;
import com.example.utils.Constant;
import com.example.utils.Methods;
import com.example.utils.SharedPref;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.PopupMenu;
import androidx.recyclerview.widget.RecyclerView;


public class AdapterComments extends RecyclerView.Adapter<AdapterComments.MyViewHolder> {

    ArrayList<ItemComment> arrayList;
    Context context;
    SharedPref sharedPref;
    Methods methods;
    ClickListener clickListener;

    class MyViewHolder extends RecyclerView.ViewHolder {
        RoundedImageView iv_dp;
        ImageView imageView_more;
        TextView textView_name, textView_comment, textView_date;

        MyViewHolder(View view) {
            super(view);
            iv_dp = view.findViewById(R.id.iv_comment_pro);
            textView_name = view.findViewById(R.id.tv_comment_name);
            textView_comment = view.findViewById(R.id.tv_comment);
            textView_date = view.findViewById(R.id.tv_comment_date);
            imageView_more = view.findViewById(R.id.iv_comment_more);
            textView_comment.setMaxLines(2);
        }
    }

    public AdapterComments(Context context, ArrayList<ItemComment> arrayList, ClickListener clickListener) {
        this.arrayList = arrayList;
        this.context = context;
        this.clickListener = clickListener;
        methods = new Methods(context);
        sharedPref = new SharedPref(context);
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_comment, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, int position) {

        Picasso.get().load(Constant.URL_IMAGE + arrayList.get(position).getDp()).placeholder(R.drawable.comment2).into(holder.iv_dp);
        holder.textView_name.setTypeface(methods.getFontMedium());
        holder.textView_name.setText(arrayList.get(position).getUserName());
        holder.textView_comment.setText(arrayList.get(position).getCommentText());
        holder.textView_date.setText(arrayList.get(position).getDate());

        if (sharedPref.getUserId().equals(arrayList.get(holder.getAbsoluteAdapterPosition()).getUserId())) {
            holder.imageView_more.setVisibility(View.VISIBLE);
        } else {
            holder.imageView_more.setVisibility(View.GONE);
        }

        holder.imageView_more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openOptionPopUp(holder.imageView_more, holder.getAbsoluteAdapterPosition());
            }
        });
    }

    @Override
    public long getItemId(int id) {
        return id;
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    private void openOptionPopUp(ImageView imageView, final int pos) {
        PopupMenu popup = new PopupMenu(context, imageView);
        popup.getMenuInflater().inflate(R.menu.popup_delete, popup.getMenu());

        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem item) {
                if (item.getItemId() == R.id.popup_delete) {
                    clickListener.onClick(pos);
                }
                return true;
            }
        });
        popup.show();
    }
}