package com.example.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxError;
import com.applovin.mediation.nativeAds.MaxNativeAdListener;
import com.applovin.mediation.nativeAds.MaxNativeAdLoader;
import com.applovin.mediation.nativeAds.MaxNativeAdView;
import com.google.android.gms.ads.nativead.MediaView;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.makeramen.roundedimageview.RoundedImageView;
import com.squareup.picasso.Picasso;
import com.startapp.sdk.ads.nativead.NativeAdDetails;
import com.example.AsyncTask.LoadFav;
import com.example.allinonenewsapp.LoginActivity;
import com.example.allinonenewsapp.NewsDetailsActivity;
import com.example.allinonenewsapp.R;
import com.example.interfaces.InterAdListener;
import com.example.interfaces.SuccessListener;
import com.example.item.ItemNews;
import com.example.utils.Constant;
import com.example.utils.Methods;
import com.example.utils.MyBounceInterpolator;
import com.example.utils.SharedPref;
import com.wortise.ads.AdError;
import com.wortise.ads.natives.GoogleNativeAd;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import fr.castorflex.android.circularprogressbar.CircularProgressBar;

public class AdapterNewsByVideo extends RecyclerView.Adapter {

    Context context;
    Methods methods;
    SharedPref sharedPref;
    ArrayList<ItemNews> arrayList;
    ArrayList<ItemNews> filteredArrayList;
    NameFilter filter;

    final int VIEW_PROG = -1;

    Boolean isAdLoaded = false;
    List<NativeAd> mNativeAdsAdmob = new ArrayList<>();
    List<NativeAdDetails> nativeAdsStartApp = new ArrayList<>();


    public AdapterNewsByVideo(Context context, ArrayList<ItemNews> arrayList) {
        this.arrayList = arrayList;
        this.context = context;
        filteredArrayList = arrayList;
        methods = new Methods(context, interAdListener);
        sharedPref = new SharedPref(context);
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        TextView textView_heading, textView_date, textView_cat;
        ImageView imageView_fav, imageView_play;
        RelativeLayout rl_main;
        RoundedImageView imageView;
        FloatingActionButton fab_share;

        MyViewHolder(View view) {
            super(view);
            rl_main = view.findViewById(R.id.rl_news);
            textView_heading = view.findViewById(R.id.tv_home_news_title);
            textView_date = view.findViewById(R.id.tv_home_news_date);
            textView_cat = view.findViewById(R.id.tv_home_news_cat);
            imageView = view.findViewById(R.id.imageView_home_latest);
            imageView_fav = view.findViewById(R.id.iv_home_news_fav);
            imageView_play = view.findViewById(R.id.iv_home_news_play);
            fab_share = view.findViewById(R.id.fab_home_news_share);
        }
    }

    private static class ADViewHolder extends RecyclerView.ViewHolder {
        RelativeLayout rl_native_ad;
        boolean isAdRequested = false;

        private ADViewHolder(View view) {
            super(view);
            rl_native_ad = view.findViewById(R.id.rl_native_ad);
        }
    }

    private static class ProgressViewHolder extends RecyclerView.ViewHolder {
        private static CircularProgressBar progressBar;

        private ProgressViewHolder(View v) {
            super(v);
            progressBar = v.findViewById(R.id.progressBar);
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == VIEW_PROG) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_progressbar, parent, false);
            return new ProgressViewHolder(v);
        } else if (viewType >= 1000) {
            View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_ads, parent, false);
            return new ADViewHolder(itemView);
        } else {
            View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_newsbyvideo, parent, false);
            return new MyViewHolder(itemView);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof MyViewHolder) {
            ((MyViewHolder) holder).textView_heading.setTypeface(methods.getFontMedium());

            setPlay(((MyViewHolder) holder).imageView_play, holder.getAbsoluteAdapterPosition());
            methods.setFavImage(arrayList.get(holder.getAbsoluteAdapterPosition()).getIsFav(), ((MyViewHolder) holder).imageView_fav);

            ((MyViewHolder) holder).textView_cat.setText(arrayList.get(holder.getAbsoluteAdapterPosition()).getCatName());
            ((MyViewHolder) holder).textView_heading.setText(arrayList.get(holder.getAbsoluteAdapterPosition()).getHeading());


            ((MyViewHolder) holder).textView_date.setText(arrayList.get(holder.getAbsoluteAdapterPosition()).getDate());

            Picasso.get()
                    .load(methods.getImageThumbSize(arrayList.get(holder.getAbsoluteAdapterPosition()).getImageThumb(), "header"))
                    .placeholder(R.drawable.placeholder_news)
                    .into(((MyViewHolder) holder).imageView);


            ((MyViewHolder) holder).imageView_fav.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if (sharedPref.isLogged()) {
                        didTapFav(((MyViewHolder) holder).imageView_fav);
                        loadFav(arrayList.get(holder.getAbsoluteAdapterPosition()).getId(), holder.getAbsoluteAdapterPosition(), ((MyViewHolder) holder).imageView_fav);
                    } else {
                        Intent intent = new Intent(context, LoginActivity.class);
                        intent.putExtra("from", "app");
                        context.startActivity(intent);
                    }
                }
            });

            ((MyViewHolder) holder).rl_main.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    methods.showInterAd(holder.getAbsoluteAdapterPosition(), "");
                }
            });

            ((MyViewHolder) holder).imageView_play.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    methods.startVideoPlay(arrayList.get(holder.getAbsoluteAdapterPosition()).getVideoId());
                }
            });

            ((MyViewHolder) holder).fab_share.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    methods.shareNews(arrayList.get(holder.getAbsoluteAdapterPosition()));
                }
            });
        } else if (holder instanceof ADViewHolder) {
            if (isAdLoaded) {
                if (((ADViewHolder) holder).rl_native_ad.getChildCount() == 0) {
                    switch (Constant.nativeAdType) {
                        case Constant.AD_TYPE_ADMOB:
                        case Constant.AD_TYPE_FACEBOOK:
                            if (mNativeAdsAdmob.size() >= 1) {

                                int i = new Random().nextInt(mNativeAdsAdmob.size() - 1);

                                NativeAdView adView = (NativeAdView) ((Activity) context).getLayoutInflater().inflate(R.layout.layout_native_ad_admob, null);
                                populateUnifiedNativeAdView(mNativeAdsAdmob.get(i), adView);
                                ((ADViewHolder) holder).rl_native_ad.removeAllViews();
                                ((ADViewHolder) holder).rl_native_ad.addView(adView);

                                ((ADViewHolder) holder).rl_native_ad.setVisibility(View.VISIBLE);
                            }
                            break;
                        case Constant.AD_TYPE_STARTAPP:
                            int i = new Random().nextInt(nativeAdsStartApp.size() - 1);

                            RelativeLayout nativeAdView = (RelativeLayout) ((Activity) context).getLayoutInflater().inflate(R.layout.layout_native_ad_startapp, null);
                            populateStartAppNativeAdView(nativeAdsStartApp.get(i), nativeAdView);

                            ((ADViewHolder) holder).rl_native_ad.removeAllViews();
                            ((ADViewHolder) holder).rl_native_ad.addView(nativeAdView);
                            ((ADViewHolder) holder).rl_native_ad.setVisibility(View.VISIBLE);
                            break;
                        case Constant.AD_TYPE_APPLOVIN:
                            MaxNativeAdLoader nativeAdLoader = new MaxNativeAdLoader(Constant.nativeAdID, context);
                            nativeAdLoader.setNativeAdListener(new MaxNativeAdListener() {
                                @Override
                                public void onNativeAdLoaded(final MaxNativeAdView nativeAdView, final MaxAd ad) {
                                    nativeAdView.setPadding(0, 0, 0, 10);
                                    nativeAdView.setBackgroundColor(Color.WHITE);
                                    ((ADViewHolder) holder).rl_native_ad.removeAllViews();
                                    ((ADViewHolder) holder).rl_native_ad.addView(nativeAdView);
                                    ((ADViewHolder) holder).rl_native_ad.setVisibility(View.VISIBLE);
                                }

                                @Override
                                public void onNativeAdLoadFailed(final String adUnitId, final MaxError error) {
                                }

                                @Override
                                public void onNativeAdClicked(final MaxAd ad) {
                                }
                            });

                            nativeAdLoader.loadAd();
                            break;
                        case Constant.AD_TYPE_WORTISE:
                            if (!((ADViewHolder) holder).isAdRequested) {
                                GoogleNativeAd googleNativeAd = new GoogleNativeAd(
                                        context, Constant.nativeAdID, new GoogleNativeAd.Listener() {
                                    @Override
                                    public void onNativeClicked(@NonNull GoogleNativeAd googleNativeAd) {

                                    }

                                    @Override
                                    public void onNativeFailed(@NonNull GoogleNativeAd googleNativeAd, @NonNull AdError adError) {
                                        ((ADViewHolder) holder).isAdRequested = false;
                                    }

                                    @Override
                                    public void onNativeImpression(@NonNull GoogleNativeAd googleNativeAd) {

                                    }

                                    @Override
                                    public void onNativeLoaded(@NonNull GoogleNativeAd googleNativeAd, @NonNull NativeAd nativeAd) {
                                        NativeAdView adView = (NativeAdView) ((Activity) context).getLayoutInflater().inflate(R.layout.layout_native_ad_admob, null);
                                        populateUnifiedNativeAdView(nativeAd, adView);
                                        ((ADViewHolder) holder).rl_native_ad.removeAllViews();
                                        ((ADViewHolder) holder).rl_native_ad.addView(adView);

                                        ((ADViewHolder) holder).rl_native_ad.setVisibility(View.VISIBLE);
                                    }
                                });
                                googleNativeAd.load();
                                ((ADViewHolder) holder).isAdRequested = true;
                            }
                            break;
                    }
                }
            }
        } else {
            if (getItemCount() == 1) {
                ProgressViewHolder.progressBar.setVisibility(View.GONE);
            }
        }
    }

    private void loadFav(String qid, final int posi, ImageView iv_fav) {
        if (methods.isNetworkAvailable()) {
            LoadFav loadFav = new LoadFav(new SuccessListener() {
                @Override
                public void onStart() {

                }

                @Override
                public void onEnd(String success, String favSuccess, String message) {
                    if (success.equals("1")) {
                        arrayList.get(posi).setIsFav(favSuccess.equals("1"));
                        methods.setFavImage(arrayList.get(posi).getIsFav(), iv_fav);

                        notifyItemChanged(posi);

                        methods.showToast(message);
                    }
                }
            }, methods.getAPIRequest(Constant.METHOD_FAV, 0, "", qid, "", "", "", "", "", "", "", "", sharedPref.getUserId(), "", null, null));
            loadFav.execute();
        } else {
            methods.showToast(context.getString(R.string.err_internet_not_conn));
        }
    }

    private void didTapFav(ImageView imageView) {
        final Animation myAnim = AnimationUtils.loadAnimation(context, R.anim.bubble);
        MyBounceInterpolator interpolator = new MyBounceInterpolator(0.12, 40);
        myAnim.setInterpolator(interpolator);
        imageView.startAnimation(myAnim);
    }

    private void setPlay(ImageView imageView, int pos) {
        if (arrayList.get(pos).getType().equals("video")) {
            imageView.setVisibility(View.VISIBLE);
        } else {
            imageView.setVisibility(View.GONE);
        }
    }

    public void addAds(NativeAd nativeAd) {
        mNativeAdsAdmob.add(nativeAd);
        isAdLoaded = true;
    }

    public void addNativeAds(ArrayList<NativeAdDetails> nativeAdDetails) {
        nativeAdsStartApp.addAll(nativeAdDetails);
        isAdLoaded = true;
    }

    public void setNativeAds(boolean isLoaded) {
        isAdLoaded = isLoaded;
    }

    private void populateUnifiedNativeAdView(NativeAd nativeAd, NativeAdView adView) {
        // Set the media view. Media content will be automatically populated in the media view once
        // adView.setNativeAd() is called.
        MediaView mediaView = adView.findViewById(R.id.ad_media);
        adView.setMediaView(mediaView);

        // Set other ad assets.
        adView.setHeadlineView(adView.findViewById(R.id.ad_headline));
        adView.setBodyView(adView.findViewById(R.id.ad_body));
        adView.setCallToActionView(adView.findViewById(R.id.ad_call_to_action));
        adView.setIconView(adView.findViewById(R.id.ad_icon));
        adView.setPriceView(adView.findViewById(R.id.ad_price));
        adView.setStarRatingView(adView.findViewById(R.id.ad_stars));
        adView.setStoreView(adView.findViewById(R.id.ad_store));
        adView.setAdvertiserView(adView.findViewById(R.id.ad_advertiser));

        // The headline is guaranteed to be in every UnifiedNativeAd.
        ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());

        // These assets aren't guaranteed to be in every UnifiedNativeAd, so it's important to
        // check before trying to display them.
        if (nativeAd.getBody() == null) {
            adView.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
        }

        if (nativeAd.getCallToAction() == null) {
            adView.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
        }

        if (nativeAd.getIcon() == null) {
            adView.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView.getIconView()).setImageDrawable(
                    nativeAd.getIcon().getDrawable());
            adView.getIconView().setVisibility(View.VISIBLE);
        }

        if (nativeAd.getPrice() == null) {
            adView.getPriceView().setVisibility(View.INVISIBLE);
        } else {
            adView.getPriceView().setVisibility(View.VISIBLE);
            ((TextView) adView.getPriceView()).setText(nativeAd.getPrice());
        }

        if (nativeAd.getStore() == null) {
            adView.getStoreView().setVisibility(View.INVISIBLE);
        } else {
            adView.getStoreView().setVisibility(View.VISIBLE);
            ((TextView) adView.getStoreView()).setText(nativeAd.getStore());
        }

        if (nativeAd.getStarRating() == null) {
            adView.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView.getStarRatingView())
                    .setRating(nativeAd.getStarRating().floatValue());
            adView.getStarRatingView().setVisibility(View.VISIBLE);
        }

        if (nativeAd.getAdvertiser() == null) {
            adView.getAdvertiserView().setVisibility(View.INVISIBLE);
        } else {
            ((TextView) adView.getAdvertiserView()).setText(nativeAd.getAdvertiser());
            adView.getAdvertiserView().setVisibility(View.VISIBLE);
        }

        // This method tells the Google Mobile Ads SDK that you have finished populating your
        // native ad view with this native ad. The SDK will populate the adView's MediaView
        // with the media content from this native ad.
        adView.setNativeAd(nativeAd);
    }

    private void populateStartAppNativeAdView(NativeAdDetails nativeAdDetails, RelativeLayout nativeAdView) {
        ImageView icon = nativeAdView.findViewById(R.id.icon);
        TextView title = nativeAdView.findViewById(R.id.title);
        TextView description = nativeAdView.findViewById(R.id.description);
        Button button = nativeAdView.findViewById(R.id.button);

        icon.setImageBitmap(nativeAdDetails.getImageBitmap());
        title.setText(nativeAdDetails.getTitle());
        description.setText(nativeAdDetails.getDescription());
        button.setText(nativeAdDetails.isApp() ? "Install" : "Open");
    }

    public String getId(int pos) {
        return arrayList.get(pos).getId();
    }

    @Override
    public long getItemId(int id) {
        return id;
    }

    @Override
    public int getItemCount() {
        return arrayList.size() + 1;
    }

    public boolean isHeader(int position) {
        return position == arrayList.size();
    }

    @Override
    public int getItemViewType(int position) {
        if (isHeader(position)) {
            return VIEW_PROG;
        } else if (arrayList.get(position) == null) {
            return 1000 + position;
        } else {
            return position;
        }
    }

    private boolean isProgressPos(int position) {
        return position == arrayList.size();
    }

    public void hideHeader() {
        ProgressViewHolder.progressBar.setVisibility(View.GONE);
    }

    public Filter getFilter() {
        if (filter == null) {
            filter = new NameFilter();
        }
        return filter;
    }

    private class NameFilter extends Filter {

        @Override
        protected FilterResults performFiltering(CharSequence constraint) {

            constraint = constraint.toString().toLowerCase();
            FilterResults result = new FilterResults();
            if (constraint.toString().length() > 0) {
                ArrayList<ItemNews> filteredItems = new ArrayList<>();

                for (int i = 0, l = filteredArrayList.size(); i < l; i++) {
                    String nameList = filteredArrayList.get(i).getHeading();
                    if (nameList.toLowerCase().contains(constraint))
                        filteredItems.add(filteredArrayList.get(i));
                }
                result.count = filteredItems.size();
                result.values = filteredItems;
            } else {
                synchronized (this) {
                    result.values = filteredArrayList;
                    result.count = filteredArrayList.size();
                }
            }
            return result;
        }

        @SuppressWarnings("unchecked")
        @Override
        protected void publishResults(CharSequence constraint,
                                      FilterResults results) {

            arrayList = (ArrayList<ItemNews>) results.values;
            notifyDataSetChanged();
        }
    }

    private final InterAdListener interAdListener = new InterAdListener() {
        @Override
        public void onClick(int position, String type) {
            Constant.selected_news_pos = position;
            Constant.itemNewsCurrent = arrayList.get(position);

            Intent intent = new Intent(context, NewsDetailsActivity.class);
            intent.putExtra("isuser", false);
            context.startActivity(intent);
        }
    };

    public void destroyNativeAds() {
        try {
            for (int i = 0; i < mNativeAdsAdmob.size(); i++) {
                mNativeAdsAdmob.get(i).destroy();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}