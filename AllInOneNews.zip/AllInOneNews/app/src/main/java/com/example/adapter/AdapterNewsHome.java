package com.example.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.makeramen.roundedimageview.RoundedImageView;
import com.squareup.picasso.Picasso;
import com.example.AsyncTask.LoadFav;
import com.example.allinonenewsapp.LoginActivity;
import com.example.allinonenewsapp.NewsDetailsActivity;
import com.example.allinonenewsapp.R;
import com.example.interfaces.InterAdListener;
import com.example.interfaces.SuccessListener;
import com.example.item.ItemNews;
import com.example.utils.Constant;
import com.example.utils.Methods;
import com.example.utils.MyBounceInterpolator;
import com.example.utils.SharedPref;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


public class AdapterNewsHome extends RecyclerView.Adapter<AdapterNewsHome.MyViewHolder> {

    Context context;
    Methods methods;
    SharedPref sharedPref;
    ArrayList<ItemNews> arrayList;
    ArrayList<ItemNews> filteredArrayList;
    NameFilter filter;

    public AdapterNewsHome(Context context, ArrayList<ItemNews> arrayList) {
        this.arrayList = arrayList;
        this.context = context;
        filteredArrayList = arrayList;
        methods = new Methods(context, interAdListener);
        sharedPref = new SharedPref(context);
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        TextView textView_heading, textView_date, textView_cat;
        ImageView imageView_fav, imageView_play;
        RelativeLayout rl_main;
        RoundedImageView imageView;
        FloatingActionButton fab_share;

        MyViewHolder(View view) {
            super(view);
            rl_main = view.findViewById(R.id.rl_news);
            textView_heading = view.findViewById(R.id.tv_home_news_title);
            textView_date = view.findViewById(R.id.tv_home_news_date);
            textView_cat = view.findViewById(R.id.tv_home_news_cat);
            imageView = view.findViewById(R.id.imageView_home_latest);
            imageView_fav = view.findViewById(R.id.iv_home_news_fav);
            imageView_play = view.findViewById(R.id.iv_home_news_play);
            fab_share = view.findViewById(R.id.fab_home_news_share);
        }
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_news_home, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, int position) {

        holder.textView_heading.setTypeface(methods.getFontMedium());

        setPlay(holder.imageView_play, holder.getAbsoluteAdapterPosition());
        methods.setFavImage(arrayList.get(holder.getAbsoluteAdapterPosition()).getIsFav(), holder.imageView_fav);

        holder.textView_cat.setText(arrayList.get(holder.getAbsoluteAdapterPosition()).getCatName());
        holder.textView_heading.setText(arrayList.get(holder.getAbsoluteAdapterPosition()).getHeading());
        holder.textView_date.setText(arrayList.get(holder.getAbsoluteAdapterPosition()).getDate());

        Picasso.get()
                .load(methods.getImageThumbSize(arrayList.get(holder.getAbsoluteAdapterPosition()).getImageThumb(), "home"))
                .placeholder(R.drawable.placeholder_news)
                .into(holder.imageView);


        holder.imageView_fav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (sharedPref.isLogged()) {
                    didTapFav(holder.imageView_fav);
                    loadFav(arrayList.get(holder.getAbsoluteAdapterPosition()).getId(), holder.getAbsoluteAdapterPosition(), holder.imageView_fav);
                } else {
                    Intent intent = new Intent(context, LoginActivity.class);
                    intent.putExtra("from", "app");
                    context.startActivity(intent);
                }
            }
        });

        holder.rl_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                methods.showInterAd(holder.getAbsoluteAdapterPosition(), "");
            }
        });

        holder.imageView_play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                methods.startVideoPlay(arrayList.get(holder.getAbsoluteAdapterPosition()).getVideoId());
            }
        });

        holder.fab_share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                methods.shareNews(arrayList.get(holder.getAbsoluteAdapterPosition()));
            }
        });
    }

    private void loadFav(String qid, final int posi, ImageView iv_fav) {
        if (methods.isNetworkAvailable()) {
            LoadFav loadFav = new LoadFav(new SuccessListener() {
                @Override
                public void onStart() {

                }

                @Override
                public void onEnd(String success, String favSuccess, String message) {
                    if (success.equals("1")) {
                        arrayList.get(posi).setIsFav(favSuccess.equals("1"));
                        methods.setFavImage(arrayList.get(posi).getIsFav(), iv_fav);

                        notifyItemChanged(posi);

                        methods.showToast(message);
                    }
                }
            }, methods.getAPIRequest(Constant.METHOD_FAV, 0, "", qid, "", "", "", "", "", "", "", "", sharedPref.getUserId(), "", null, null));
            loadFav.execute();
        } else {
            methods.showToast(context.getString(R.string.err_internet_not_conn));
        }
    }

    private void didTapFav(ImageView imageView) {
        final Animation myAnim = AnimationUtils.loadAnimation(context, R.anim.bubble);
        MyBounceInterpolator interpolator = new MyBounceInterpolator(0.12, 40);
        myAnim.setInterpolator(interpolator);
        imageView.startAnimation(myAnim);
    }

    private void setPlay(ImageView imageView, int pos) {
        if (arrayList.get(pos).getType().equals("video")) {
            imageView.setVisibility(View.VISIBLE);
        } else {
            imageView.setVisibility(View.GONE);
        }
    }

    public String getId(int pos) {
        return arrayList.get(pos).getId();
    }

    @Override
    public long getItemId(int id) {
        return id;
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public boolean isHeader(int position) {
        return (position + 3) % 3 == 0;
    }

    public Filter getFilter() {
        if (filter == null) {
            filter = new NameFilter();
        }
        return filter;
    }

    private class NameFilter extends Filter {

        @Override
        protected FilterResults performFiltering(CharSequence constraint) {

            constraint = constraint.toString().toLowerCase();
            FilterResults result = new FilterResults();
            if (constraint.toString().length() > 0) {
                ArrayList<ItemNews> filteredItems = new ArrayList<>();

                for (int i = 0, l = filteredArrayList.size(); i < l; i++) {
                    String nameList = filteredArrayList.get(i).getHeading();
                    if (nameList.toLowerCase().contains(constraint))
                        filteredItems.add(filteredArrayList.get(i));
                }
                result.count = filteredItems.size();
                result.values = filteredItems;
            } else {
                synchronized (this) {
                    result.values = filteredArrayList;
                    result.count = filteredArrayList.size();
                }
            }
            return result;
        }

        @SuppressWarnings("unchecked")
        @Override
        protected void publishResults(CharSequence constraint,
                                      FilterResults results) {

            arrayList = (ArrayList<ItemNews>) results.values;
            notifyDataSetChanged();
        }
    }

    private final InterAdListener interAdListener = new InterAdListener() {
        @Override
        public void onClick(int position, String type) {
            Constant.selected_news_pos = position;
            Constant.itemNewsCurrent = arrayList.get(position);

            Intent intent = new Intent(context, NewsDetailsActivity.class);
            intent.putExtra("isuser", false);
            context.startActivity(intent);
        }
    };
}