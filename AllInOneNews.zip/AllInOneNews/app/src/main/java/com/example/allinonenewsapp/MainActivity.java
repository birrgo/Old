package com.example.allinonenewsapp;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.MenuItem;
import android.widget.LinearLayout;

import com.example.utils.AdManagerInterWortise;
import com.google.android.material.navigation.NavigationView;
import com.onesignal.OneSignal;
import com.example.AsyncTask.LoadAbout;
import com.example.fragments.FragmentCat;
import com.example.fragments.FragmentFav;
import com.example.fragments.FragmentHome;
import com.example.fragments.FragmentLatest;
import com.example.fragments.FragmentVideo;
import com.example.interfaces.AboutListener;
import com.example.interfaces.AdConsentListener;
import com.example.utils.AdConsent;
import com.example.utils.AdManagerInterAdmob;
import com.example.utils.AdManagerInterApplovin;
import com.example.utils.AdManagerInterStartApp;
import com.example.utils.Constant;
import com.example.utils.DBHelper;
import com.example.utils.Methods;
import com.example.utils.SharedPref;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import io.github.inflationx.viewpump.ViewPumpContextWrapper;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    Toolbar toolbar;
    DBHelper dbHelper;
    SharedPref sharedPref;
    DrawerLayout drawer;
    ActionBarDrawerToggle toggle;
    NavigationView navigationView;
    FragmentManager fm;
    Methods methods;
    AdConsent adConsent;
    MenuItem menuItemLogin, menuItemProfile, menuItemUpload;
    LinearLayout ll_adView;

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sharedPref = new SharedPref(this);

        OneSignal.sendTag("user_id", sharedPref.getUserId());

//        try {
//            PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), PackageManager.GET_SIGNATURES);
//            for (Signature signature : info.signatures) {
//                MessageDigest md = MessageDigest.getInstance("SHA");
//                md.update(signature.toByteArray());
//                Log.d("KeyHash:", Base64.encodeToString(md.digest(), Base64.DEFAULT));
//            }
//        } catch (NoSuchAlgorithmException e) {
//            Log.e("aaa", "printHashKey()", e);
//        } catch (Exception e) {
//            Log.e("aaa", "printHashKey()", e);
//        }

        ll_adView = findViewById(R.id.ll_adView);
        methods = new Methods(this);
        methods.forceRTLIfSupported(getWindow());

        dbHelper = new DBHelper(this);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        fm = getSupportFragmentManager();

        drawer = findViewById(R.id.drawer_layout);
        toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        menuItemLogin = navigationView.getMenu().findItem(R.id.nav_login);
        menuItemProfile = navigationView.getMenu().findItem(R.id.nav_profile);
        menuItemUpload = navigationView.getMenu().findItem(R.id.nav_upload);
        setLoginButton(menuItemLogin, menuItemProfile, MainActivity.this);

        FragmentHome f1 = new FragmentHome();
        loadFrag(f1, getString(R.string.home), fm);
        navigationView.setCheckedItem(R.id.nav_home);

        adConsent = new AdConsent(this, new AdConsentListener() {
            @Override
            public void onConsentUpdate() {
                methods.showBannerAd(ll_adView);
            }
        });

        if (methods.isNetworkAvailable()) {
            loadAboutData();
        } else {
            adConsent.checkForConsent();
            dbHelper.getAbout();
            methods.showToast(getString(R.string.err_internet_not_conn));
        }

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else if (fm.getBackStackEntryCount() != 0) {
            String title = fm.getFragments().get(fm.getBackStackEntryCount() - 1).getTag();
            if (title.equals(getString(R.string.home))) {
                navigationView.setCheckedItem(R.id.nav_home);
            }
            getSupportActionBar().setTitle(title);
            super.onBackPressed();
        } else {
            exitDialog();
        }
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.

        switch (item.getItemId()) {
            case R.id.nav_home:
                FragmentHome f1 = new FragmentHome();
                loadFrag(f1, getString(R.string.home), fm);
                break;
            case R.id.nav_latest:
                FragmentLatest flatest = new FragmentLatest();
                loadFrag(flatest, getString(R.string.latest), fm);
                break;
            case R.id.nav_login:
                methods.clickLogin();
                break;
            case R.id.nav_video:
                FragmentVideo fvideo = new FragmentVideo();
                loadFrag(fvideo, getString(R.string.video_news), fm);
                toolbar.setTitle(getString(R.string.video_news));
                break;
            case R.id.nav_cat:
                FragmentCat fcat = new FragmentCat();
                loadFrag(fcat, getString(R.string.categories), fm);
                toolbar.setTitle(getString(R.string.categories));
                break;
            case R.id.nav_fav:
                FragmentFav ffav = new FragmentFav();
                loadFrag(ffav, getString(R.string.favourite), fm);
                toolbar.setTitle(getString(R.string.favourite));
                break;
            case R.id.nav_upload:
                Intent intent_upload = new Intent(MainActivity.this, UploadsNewsActivity.class);
                startActivity(intent_upload);
                break;
            case R.id.nav_profile:
                Intent intent = new Intent(MainActivity.this, ProfileActivity.class);
                startActivity(intent);
                break;
            case R.id.nav_shareapp:
                Intent ishare = new Intent(Intent.ACTION_SEND);
                ishare.setType("text/plain");
                ishare.putExtra(Intent.EXTRA_TEXT, getResources().getString(R.string.app_name) + " - http://play.google.com/store/apps/details?id=" + getPackageName());
                startActivity(ishare);
                break;
            case R.id.nav_settings:
                Intent intent_set = new Intent(MainActivity.this, SettingActivity.class);
                startActivity(intent_set);
                break;
        }

        navigationView.setCheckedItem(item.getItemId());
        drawer.closeDrawer(GravityCompat.START);

        return true;
    }

    public void loadFrag(Fragment f1, String name, FragmentManager fm) {
        for (int i = 0; i < fm.getBackStackEntryCount(); ++i) {
            fm.popBackStack();
        }

        FragmentTransaction ft = fm.beginTransaction();
//        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);

        if (!name.equals(getString(R.string.home))) {
            ft.hide(fm.getFragments().get(fm.getFragments().size() - 1));
            ft.add(R.id.frame_nav, f1, name);
            ft.addToBackStack(name);
        } else {
            ft.replace(R.id.frame_nav, f1, name);
        }
        ft.commit();

        getSupportActionBar().setTitle(name);
    }

    public void loadAboutData() {
        LoadAbout loadAbout = new LoadAbout(MainActivity.this, new AboutListener() {
            @Override
            public void onStart() {
            }

            @Override
            public void onEnd(String success, String verifyStatus, String message, String userCategory) {
                if (!verifyStatus.equals("-1")) {
                    String version = "";
                    try {
                        PackageInfo pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
                        version = String.valueOf(pInfo.versionCode);
                    } catch (PackageManager.NameNotFoundException e) {
                        e.printStackTrace();
                    }
                    if (Constant.showUpdateDialog && !Constant.appVersion.equals(version)) {
                        methods.showUpdateAlert(Constant.appUpdateMsg, false);
                    } else {
                        adConsent.checkForConsent();
                        dbHelper.addtoAbout();
                    }

                    if(sharedPref.isLogged()) {
                        sharedPref.setCat(userCategory);
                    }

                    methods.initializeAds();

                    sharedPref.setAdDetails(Constant.isBannerAd, Constant.isInterstitialAd, Constant.isNativeAd, Constant.bannerAdType,
                            Constant.interstitialAdType, Constant.nativeAdType, Constant.bannerAdID, Constant.interstitialAdID, Constant.nativeAdID, Constant.startapp_id, Constant.interstitialAdShow, Constant.nativeAdShow);

                    if (Constant.isInterstitialAd) {
                        switch (Constant.interstitialAdType) {
                            case Constant.AD_TYPE_ADMOB:
                            case Constant.AD_TYPE_FACEBOOK:
                                AdManagerInterAdmob adManagerInterAdmob = new AdManagerInterAdmob(getApplicationContext());
                                adManagerInterAdmob.createAd();
                                break;
                            case Constant.AD_TYPE_STARTAPP:
                                AdManagerInterStartApp adManagerInterStartApp = new AdManagerInterStartApp(getApplicationContext());
                                adManagerInterStartApp.createAd();
                                break;
                            case Constant.AD_TYPE_APPLOVIN:
                                AdManagerInterApplovin adManagerInterApplovin = new AdManagerInterApplovin(MainActivity.this);
                                adManagerInterApplovin.createAd();
                                break;
                            case Constant.AD_TYPE_WORTISE:
                                AdManagerInterWortise adManagerInterWortise = new AdManagerInterWortise(MainActivity.this);
                                adManagerInterWortise.createAd();
                                break;
                        }
                    }
                } else {
                    methods.getVerifyDialog(getString(R.string.error_unauth_access), message);
                }
            }
        }, methods.getAPIRequest(Constant.METHOD_APP_DETAILS, 0, "", "", "", "", "", "", "", "", "", "", sharedPref.getUserId(), "", null, null));
        loadAbout.execute();
    }

    private void exitDialog() {
        AlertDialog.Builder alert = new AlertDialog.Builder(MainActivity.this, R.style.AlertDialogTheme);
        alert.setTitle(getString(R.string.exit));
        alert.setMessage(getString(R.string.sure_exit));
        alert.setPositiveButton(getString(R.string.exit), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
            }
        });
        alert.setNegativeButton(getString(R.string.cancel), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        alert.show();
    }

    public void setLoginButton(MenuItem buttonLogin, MenuItem buttonProfile, Context context) {
        if (sharedPref.isLogged()) {
            buttonLogin.setTitle(context.getResources().getString(R.string.logout));
            buttonLogin.setIcon(context.getResources().getDrawable(R.drawable.logout));
            buttonProfile.setVisible(true);
        } else {
            buttonLogin.setTitle(context.getResources().getString(R.string.login));
            buttonLogin.setIcon(context.getResources().getDrawable(R.drawable.login));
            buttonProfile.setVisible(false);
        }
    }

    @Override
    protected void onResume() {
        if (menuItemLogin != null) {
            setLoginButton(menuItemLogin, menuItemProfile, MainActivity.this);
            menuItemUpload.setVisible(sharedPref.getIsReporter());
        }
        super.onResume();
    }

    @Override
    protected void onDestroy() {
        try {
            dbHelper.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroy();
    }
}