package com.example.allinonenewsapp;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.AsyncTask.LoadApplyReporter;
import com.example.AsyncTask.LoadNews;
import com.example.AsyncTask.LoadProfile;
import com.example.adapter.AdapterLatest;
import com.example.eventbus.EventDelete;
import com.example.eventbus.GlobalBus;
import com.example.interfaces.NewsListener;
import com.example.interfaces.ProfileListener;
import com.example.interfaces.SuccessListener;
import com.example.item.ItemNews;
import com.example.utils.Constant;
import com.example.utils.EndlessRecyclerViewScrollListener;
import com.example.utils.Methods;
import com.example.utils.MySingleton;
import com.example.utils.SharedPref;
import com.google.ads.consent.ConsentInformation;
import com.google.ads.consent.ConsentStatus;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.ads.mediation.facebook.FacebookMediationAdapter;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.material.button.MaterialButton;
import com.makeramen.roundedimageview.RoundedImageView;
import com.squareup.picasso.Picasso;
import com.startapp.sdk.ads.nativead.NativeAdPreferences;
import com.startapp.sdk.ads.nativead.StartAppNativeAd;
import com.startapp.sdk.adsbase.Ad;
import com.startapp.sdk.adsbase.adlisteners.AdEventListener;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;
import fr.castorflex.android.circularprogressbar.CircularProgressBar;
import io.github.inflationx.viewpump.ViewPumpContextWrapper;

public class ProfileActivity extends AppCompatActivity {

    Toolbar toolbar;
    Methods methods;
    SharedPref sharedPref;
    RecyclerView rv_profile;
    AdapterLatest myAdapter;
    ArrayList<ItemNews> arrayList;
    RoundedImageView iv_prof;
    TextView textView_email, textView_mobile, textView_notlog, tv_hello;
    ProgressDialog progressDialog;
    MaterialButton btn_apply_reporter, btn_add_news;
    CircularProgressBar progressBar;
    int page = 1, totalArraySize = 0;
    Boolean isOver = false, isScroll = false;
    Dialog dialog_request;

    TextView textView_empty;
    AppCompatButton button_try;
    LinearLayout ll_empty;
    String errr_msg;

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        toolbar = findViewById(R.id.toolbar_pro);
        toolbar.setTitle("");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        methods = new Methods(this);
        sharedPref = new SharedPref(this);

        arrayList = new ArrayList<>();

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage(getResources().getString(R.string.loading));
        progressDialog.setCancelable(false);

        ll_empty = findViewById(R.id.ll_empty);
        textView_empty = findViewById(R.id.textView_empty_msg);
        button_try = findViewById(R.id.button_empty_try);
        errr_msg = getString(R.string.no_news_found);

//        collapsing = findViewById(R.id.collapsing);
//        collapsing.setTitle(Constant.itemUser.getName());

        btn_add_news = findViewById(R.id.btn_details_add_news);
        btn_apply_reporter = findViewById(R.id.btn_profile_apply_reporter);
        rv_profile = findViewById(R.id.rv_profile);
        iv_prof = findViewById(R.id.iv_prof);
        progressBar = findViewById(R.id.progressBar_prof);
        textView_email = findViewById(R.id.tv_prof_email);
        textView_mobile = findViewById(R.id.tv_prof_mobile);
        textView_notlog = findViewById(R.id.textView_notlog);
        tv_hello = findViewById(R.id.tv_details_hello);

        tv_hello.setText(getString(R.string.hello) + " " + sharedPref.getUserName() + ",");

        LinearLayout ll_adView = findViewById(R.id.ll_adView);
        methods.showBannerAd(ll_adView);

        LinearLayoutManager llm = new LinearLayoutManager(this);
        rv_profile.setLayoutManager(llm);
        rv_profile.setItemAnimator(new DefaultItemAnimator());

        rv_profile.addOnScrollListener(new EndlessRecyclerViewScrollListener(llm) {
            @Override
            public void onLoadMore(int p, int totalItemsCount) {
                if (!isOver) {
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            isScroll = true;
                            loadNewsData();
                        }
                    }, 0);
                } else {
                    myAdapter.hideHeader();
                }
            }
        });

        button_try.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadNewsData();
            }
        });

        btn_add_news.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfileActivity.this, UploadsNewsActivity.class);
                startActivity(intent);
            }
        });

        if (sharedPref.isLogged()) {
            if (sharedPref.getIsReporter()) {
                btn_add_news.setVisibility(View.VISIBLE);
                if (methods.isNetworkAvailable()) {
                    loadUserProfile();
                } else {
                    setEmpty(true, getString(R.string.err_internet_not_conn));
                }
            } else {
                btn_add_news.setVisibility(View.GONE);
                loadUserProfile();

                btn_apply_reporter.setVisibility(View.VISIBLE);
                btn_apply_reporter.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (sharedPref.getLoginType().equals(Constant.LOGIN_TYPE_NORMAL)) {
                            loadApplyReporter("", "");
                        } else {
                            openAdminDetailDialog();
                        }
                    }
                });
            }
        } else {
            setEmpty(true, getString(R.string.not_log));
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_profile, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                break;
            case R.id.item_profile_edit:
                Intent intent = new Intent(ProfileActivity.this, ProfileEditActivity.class);
                startActivity(intent);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void loadUserProfile() {
        LoadProfile loadProfile = new LoadProfile(new ProfileListener() {
            @Override
            public void onStart() {
                progressDialog.show();
            }

            @Override
            public void onEnd(String success, String isWorkSuccess, String message, String name, String email, String mobile, String profileImage, boolean isReporter) {
                progressDialog.dismiss();
                if (success.equals("1")) {
                    switch (isWorkSuccess) {
                        case "1":
                            sharedPref.setUserName(name);
                            sharedPref.setUserEmail(email);
                            sharedPref.setUserMobile(mobile);
                            sharedPref.setProfileImage(profileImage);
                            sharedPref.setIsReporter(isReporter);
                            setVariables();
                            break;
                        case "-2":
                            methods.getInvalidUserDialog(message);
                            break;
                        case "-1":
                            methods.getVerifyDialog(getString(R.string.error_unauth_access), message);
                            break;
                        default:
                            setEmpty(false, message);
                            break;
                    }
                } else {
                    Toast.makeText(ProfileActivity.this, getString(R.string.server_error), Toast.LENGTH_SHORT).show();
                }

                if (sharedPref.getIsReporter()) {
                    loadNewsData();
                }
            }
        }, methods.getAPIRequest(Constant.METHOD_PROFILE, 0, "", "", "", "", "", "", "", "", "", "", sharedPref.getUserId(), "", null, null));
        loadProfile.execute();
    }

    private void openAdminDetailDialog() {
        dialog_request = new Dialog(ProfileActivity.this);
        dialog_request.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog_request.setContentView(R.layout.layout_dialog_admin);
        if (getString(R.string.isRTL).equals("true")) {
            dialog_request.getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        }
        dialog_request.getWindow().setLayout(ViewPager.LayoutParams.MATCH_PARENT, ViewPager.LayoutParams.WRAP_CONTENT);
        dialog_request.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        AppCompatButton et_button = dialog_request.findViewById(R.id.btn_admin_submit);
        AppCompatEditText et_email = dialog_request.findViewById(R.id.et_admin_email);
        AppCompatEditText et_password = dialog_request.findViewById(R.id.et_admin_password);

        et_email.setText(sharedPref.getUserEmail());
        if (!et_email.getText().toString().trim().equals("")) {
            et_email.setEnabled(false);
        }

        et_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (et_email.getText().toString().trim().equals("")) {
                    Toast.makeText(ProfileActivity.this, getString(R.string.enter_email), Toast.LENGTH_SHORT).show();
                } else if (et_password.getText().toString().trim().equals("")) {
                    Toast.makeText(ProfileActivity.this, getString(R.string.enter_password), Toast.LENGTH_SHORT).show();
                } else {
                    loadApplyReporter(et_email.getText().toString(), et_password.getText().toString());
                }
            }
        });

        dialog_request.show();

    }

    private void loadNewsData() {
        if (methods.isNetworkAvailable()) {
            LoadNews loadNews = new LoadNews(new NewsListener() {
                @Override
                public void onStart() {
                    if (arrayList.size() == 0) {
                        ll_empty.setVisibility(View.GONE);
                        rv_profile.setVisibility(View.GONE);
                        progressBar.setVisibility(View.VISIBLE);
                    }
                }

                @Override
                public void onEnd(String success, String verifyStatus, String message, ArrayList<ItemNews> arrayListNews, int totalNews) {
                    if (success.equals("1")) {
                        if (!verifyStatus.equals("-1")) {
                            if (arrayListNews.size() == 0) {
                                isOver = true;
                                try {
                                    myAdapter.hideHeader();
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            } else {
                                totalArraySize = totalArraySize + arrayListNews.size();
                                for (int i = 0; i < arrayListNews.size(); i++) {
                                    arrayList.add(arrayListNews.get(i));

                                    if (Constant.isNativeAd) {
                                        int abc = arrayList.lastIndexOf(null);
                                        if (((arrayList.size() - (abc + 1)) % Constant.nativeAdShow == 0) && (arrayListNews.size() - 1 != i || totalArraySize != totalNews)) {
                                            arrayList.add(null);
                                        }
                                    }
                                }

                                page = page + 1;
                            }
                            errr_msg = getString(R.string.no_news_found);
                        } else {
                            methods.getVerifyDialog(getString(R.string.error_unauth_access), message);
                        }
                    } else {
                        errr_msg = getString(R.string.err_server_no_conn);
                    }
                    setAdapter();
                    progressBar.setVisibility(View.GONE);
                }
            }, methods.getAPIRequest(Constant.METHOD_USER_UPLOAD_LIST, page, "", "", "", "", "", "", "", "", "", "", sharedPref.getUserId(), "", null, null));

            loadNews.execute();
        } else {
            isOver = true;
            errr_msg = getString(R.string.err_internet_not_conn);
            setEmpty();
        }
    }

    private void loadApplyReporter(String email, String password) {
        if (methods.isNetworkAvailable()) {

            LoadApplyReporter loadApplyReporter = new LoadApplyReporter(new SuccessListener() {
                @Override
                public void onStart() {
                    progressDialog.show();
                }

                @Override
                public void onEnd(String success, String registerSuccess, String message) {
                    progressDialog.dismiss();
                    if (success.equals("1")) {
                        Toast.makeText(ProfileActivity.this, message, Toast.LENGTH_SHORT).show();
                        if (registerSuccess.equals("1")) {
                            btn_apply_reporter.setText(getString(R.string.applied_reporter));
                        } else {
                            btn_apply_reporter.setText(message);
                        }
                        btn_apply_reporter.setEnabled(false);
                        if (dialog_request != null && dialog_request.isShowing()) {
                            dialog_request.dismiss();
                        }
                    } else {
                        Toast.makeText(ProfileActivity.this, getString(R.string.err_server_no_conn), Toast.LENGTH_SHORT).show();
                    }
                }
            }, methods.getAPIRequest(Constant.METHOD_APPLY_REPORTER, 0, "", "", "", "", "", "", email, password, "", "", sharedPref.getUserId(), "", null, null));
            loadApplyReporter.execute();
        } else {
            Toast.makeText(this, getString(R.string.err_internet_not_conn), Toast.LENGTH_SHORT).show();
        }
    }

    @SuppressLint("MissingPermission")
    private void loadNativeAds() {
        if (Constant.isNativeAd && arrayList.size() >= 10) {
            switch (Constant.nativeAdType) {
                case Constant.AD_TYPE_ADMOB:
                case Constant.AD_TYPE_FACEBOOK:
                    AdLoader.Builder builder = new AdLoader.Builder(ProfileActivity.this, Constant.nativeAdID);
                    AdLoader adLoader = builder.forNativeAd(
                            new NativeAd.OnNativeAdLoadedListener() {
                                @Override
                                public void onNativeAdLoaded(@NotNull NativeAd nativeAd) {
                                    // A native ad loaded successfully, check if the ad loader has finished loading
                                    // and if so, insert the ads into the list.
                                    try {
//                                        if(adLoader.isLoading()) {
                                        myAdapter.addAds(nativeAd);
//                                        }
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                            }).build();

                    // Load the Native Express ad.
                    Bundle extras = new Bundle();
                    if (ConsentInformation.getInstance(ProfileActivity.this).getConsentStatus() != ConsentStatus.PERSONALIZED) {
                        extras.putString("npa", "1");
                    }
                    AdRequest adRequest = new AdRequest.Builder()
                            .addNetworkExtrasBundle(AdMobAdapter.class, extras)
                            .addNetworkExtrasBundle(FacebookMediationAdapter.class, extras)
                            .build();

                    adLoader.loadAds(adRequest, 5);
                    break;
                case Constant.AD_TYPE_STARTAPP:
                    StartAppNativeAd nativeAd = new StartAppNativeAd(ProfileActivity.this);

                    nativeAd.loadAd(new NativeAdPreferences()
                            .setAdsNumber(3)
                            .setAutoBitmapDownload(true)
                            .setPrimaryImageSize(2), new AdEventListener() {
                        @Override
                        public void onReceiveAd(Ad ad) {
                            try {
                                myAdapter.addNativeAds(nativeAd.getNativeAds());
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }

                        @Override
                        public void onFailedToReceiveAd(Ad ad) {
                        }
                    });
                    break;
                case Constant.AD_TYPE_APPLOVIN:
                case Constant.AD_TYPE_WORTISE:
                    myAdapter.setNativeAds(true);
                    break;
            }
        }
    }

    public void setAdapter() {
        try {
            if (!isScroll) {
                myAdapter = new AdapterLatest(ProfileActivity.this, arrayList, true);
                rv_profile.setAdapter(myAdapter);
                setEmpty();

                loadNativeAds();
            } else {
                myAdapter.notifyDataSetChanged();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setEmpty() {
        progressBar.setVisibility(View.GONE);
        if (arrayList.size() > 0) {
            rv_profile.setVisibility(View.VISIBLE);
            ll_empty.setVisibility(View.GONE);
        } else {
            textView_empty.setText(errr_msg);
            rv_profile.setVisibility(View.GONE);
            ll_empty.setVisibility(View.VISIBLE);
        }
    }

    public void setVariables() {
        textView_mobile.setText(sharedPref.getUserMobile());
        textView_email.setText(sharedPref.getUserEmail());

//        collapsing.setTitle(Constant.itemUser.getName());
        tv_hello.setText(getString(R.string.hello) + " " + sharedPref.getUserName() + ",");

        if (!sharedPref.getProfileImage().equals("")) {
            Picasso.get().load(sharedPref.getProfileImage()).placeholder(R.drawable.placeholder_prof).into(iv_prof);
        }

        if (sharedPref.getIsReporter()) {
            btn_add_news.setVisibility(View.VISIBLE);
            btn_apply_reporter.setVisibility(View.GONE);
        }
    }

    public void setEmpty(Boolean flag, String message) {
        if (flag) {
            textView_notlog.setText(message);
            textView_notlog.setVisibility(View.VISIBLE);
        } else {
            textView_notlog.setVisibility(View.GONE);
        }
    }

    @Override
    public void onResume() {
        if (Constant.isUpdate) {
            Constant.isUpdate = false;
            setVariables();
        }
        super.onResume();
    }

    @Subscribe(sticky = true, threadMode = ThreadMode.MAIN)
    public void onDelete(EventDelete eventDelete) {
        try {
            arrayList.clear();
            arrayList.addAll(MySingleton.getInstance().getNews());
            myAdapter.notifyDataSetChanged();
            GlobalBus.getBus().removeStickyEvent(eventDelete);
        } catch (Exception e) {
            GlobalBus.getBus().removeStickyEvent(eventDelete);
            e.printStackTrace();
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        GlobalBus.getBus().register(this);
    }

    @Override
    public void onStop() {
        GlobalBus.getBus().unregister(this);
        super.onStop();
    }
}