package com.example.allinonenewsapp;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.makeramen.roundedimageview.RoundedImageView;
import com.squareup.picasso.Picasso;
import com.example.AsyncTask.LoadCat;
import com.example.AsyncTask.LoadUpload;
import com.example.adapter.AdapterGalleryEdit;
import com.example.interfaces.CatListener;
import com.example.interfaces.SuccessListener;
import com.example.item.ItemCat;
import com.example.item.ItemGallery;
import com.example.item.ItemNews;
import com.example.utils.Constant;
import com.example.utils.Methods;
import com.example.utils.MultiSelectSpinner;
import com.example.utils.SharedPref;
import com.wdullaer.materialdatetimepicker.date.DatePickerDialog;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import io.github.inflationx.viewpump.ViewPumpContextWrapper;

public class UploadedNewsEditActivity extends AppCompatActivity implements DatePickerDialog.OnDateSetListener {

    Methods methods;
    SharedPref sharedPref;
    ProgressDialog progressDialog, progress;
    LinearLayout ll_url;
    RecyclerView rv_upload_gallery;
    AdapterGalleryEdit adapterGallery;
    Spinner spinner_type;
    CardView cv_gallery;
    MultiSelectSpinner spinner_cat;
    AppCompatButton button_submit, button_upload_gallery;
    AppCompatEditText et_title, et_url, et_description;
    TextView tv_date;
    ImageView iv_image;
    RoundedImageView iv_upload_gallery;
    ArrayList<String> arrayList_cat, arrayList_catid, arrayListType;
    ArrayList<File> arrayList_file;
    ArrayList<Uri> arrayList_file_gallery;
    ArrayList<ItemGallery> arrayList_item_gallery;
    int PICK_IMAGE_REQUEST = 1;
    int PICK_MULTIPLE_IMAGE_REQUEST = 2;
    Uri imageUri;
    String cat_id = "", type = "";

    private ItemNews itemNews;

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase));
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_news);

        Toolbar toolbar = findViewById(R.id.toolbar_upload);
        toolbar.setTitle(getString(R.string.edit_news));
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        methods = new Methods(this);
        sharedPref = new SharedPref(this);

        itemNews = Constant.itemNewsCurrent;

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage(getResources().getString(R.string.loading));
        progressDialog.setCancelable(false);

        progress = new ProgressDialog(this);
        progress.setMessage(getResources().getString(R.string.loading));
        progress.setCancelable(false);

        cv_gallery = findViewById(R.id.cv_upload_gallery);
        rv_upload_gallery = findViewById(R.id.rv_upload_gallery);
        ll_url = findViewById(R.id.ll_upload_video_url);
        button_submit = findViewById(R.id.button_upload_wall_submit);
        button_upload_gallery = findViewById(R.id.btn_upload_add_gallery);
        et_title = findViewById(R.id.et_upload_video_title);
        et_url = findViewById(R.id.et_upload_video_url);
        et_description = findViewById(R.id.et_upload_description);
        tv_date = findViewById(R.id.tv_upload_video_date);

        iv_image = findViewById(R.id.iv_upload_wall_submit);
        iv_upload_gallery = findViewById(R.id.iv_upload_gallery);

        arrayList_cat = new ArrayList<>();
        arrayList_catid = new ArrayList<>();
        arrayListType = new ArrayList<>();
        arrayList_file_gallery = new ArrayList<>();
        arrayList_item_gallery = new ArrayList<>();
        arrayList_file = new ArrayList<>();

        arrayListType.add("Image");
        arrayListType.add("Video");

        rv_upload_gallery.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));

        spinner_cat = findViewById(R.id.spinner_upload_wallcat);
        spinner_type = findViewById(R.id.spinner_upload_video_type);
        ArrayAdapter<String> adapterType = new ArrayAdapter<>(this, R.layout.layout_spinner, arrayListType);
        spinner_type.setAdapter(adapterType);

        spinner_cat.hasNoneOption(false);

        if (methods.isNetworkAvailable()) {
            loadAllCat();
        } else {
            Toast.makeText(this, getResources().getString(R.string.err_internet_not_conn), Toast.LENGTH_SHORT).show();
        }

        iv_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (methods.checkPer()) {
                    pickImage();
                }
            }
        });

        iv_upload_gallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (methods.checkPer()) {
                    pickMultipleImage();
                }
            }
        });

        button_upload_gallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (methods.checkPer()) {
                    pickMultipleImage();
                }
            }
        });

        tv_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar now = Calendar.getInstance();
                DatePickerDialog dpd = DatePickerDialog.newInstance(
                        UploadedNewsEditActivity.this,
                        now.get(Calendar.YEAR), // Initial year selection
                        now.get(Calendar.MONTH), // Initial month selection
                        now.get(Calendar.DAY_OF_MONTH) // Inital day selection
                );
// If you're calling this from a support Fragment
                dpd.show(getSupportFragmentManager(), "Datepickerdialog");
            }
        });

        button_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (sharedPref.isLogged()) {
                    if (methods.isNetworkAvailable()) {
                        if (et_title.getText().toString().trim().equals("")) {
                            Toast.makeText(UploadedNewsEditActivity.this, getResources().getString(R.string.enter_news_title), Toast.LENGTH_SHORT).show();
                        } else if (cat_id.equals("")) {
                            Toast.makeText(UploadedNewsEditActivity.this, getResources().getString(R.string.select_1_cat), Toast.LENGTH_SHORT).show();
                        } else if (tv_date.getText().toString().trim().equals("")) {
                            Toast.makeText(UploadedNewsEditActivity.this, getResources().getString(R.string.enter_date), Toast.LENGTH_SHORT).show();
                        } else if (spinner_type.getSelectedItemPosition() == 1 && et_url.getText().toString().trim().equals("")) {
                            Toast.makeText(UploadedNewsEditActivity.this, getResources().getString(R.string.enter_url), Toast.LENGTH_SHORT).show();
                        } else {
                            try {
                                uploadNews();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    } else {
                        Toast.makeText(UploadedNewsEditActivity.this, getResources().getString(R.string.err_internet_not_conn), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    methods.clickLogin();
                }
            }
        });


        spinner_cat.setListener(new MultiSelectSpinner.OnMultipleItemsSelectedListener() {
            @Override
            public void selectedIndices(List<Integer> indices) {
                if (indices.size() > 0) {
                    cat_id = arrayList_catid.get(indices.get(0));
                    for (int i = 1; i < indices.size(); i++) {
                        cat_id = cat_id + "," + arrayList_catid.get(indices.get(i));
                    }
                } else {
                    cat_id = "";
                }
            }

            @Override
            public void selectedStrings(List<String> strings) {

            }
        });

        spinner_type.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 0) {
                    type = "image";
                    ll_url.setVisibility(View.GONE);
                    cv_gallery.setVisibility(View.VISIBLE);
                } else if (i == 1) {
                    type = "video";
                    ll_url.setVisibility(View.VISIBLE);
                    cv_gallery.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    private void loadAllCat() {
        LoadCat loadAllCat = new LoadCat(new CatListener() {
            @Override
            public void onStart() {
                progress.show();
            }

            @Override
            public void onEnd(String success, String verifyStatus, String message, ArrayList<ItemCat> arrayListCat) {
                progress.dismiss();
                if (success.equals("1")) {
                    switch (verifyStatus) {
                        case "1":

                            String[] selectedCat = itemNews.getCatId().split(",");
                            int[] arrayListSelected = new int[selectedCat.length];

                            if (selectedCat.length > 0) {
                                cat_id = selectedCat[0];
                            }

                            int size = 0;
                            for (int i = 0; i < arrayListCat.size(); i++) {
                                arrayList_cat.add(arrayListCat.get(i).getName());
                                arrayList_catid.add(arrayListCat.get(i).getId());

                                for (int j = 0; j < selectedCat.length; j++) {
                                    String s = selectedCat[j];
                                    if (arrayListCat.get(i).getId().equals(s)) {
                                        arrayListSelected[size] = i;
                                        size = size + 1;
                                        if (j > 0) {
                                            cat_id = cat_id + "," + selectedCat[j];
                                        }

                                        break;
                                    }
                                }
                            }

                            String[] mStringArray = new String[arrayList_cat.size()];
                            mStringArray = arrayList_cat.toArray(mStringArray);

                            spinner_cat.setItems(mStringArray);

                            spinner_cat.setSelection(arrayListSelected);

                            setNewsData();
                            break;
                        case "-2":
                            methods.getInvalidUserDialog(message);
                            break;
                        case "-1":
                            methods.getVerifyDialog(getString(R.string.error_unauth_access), message);
                            break;
                    }
                }
            }
        }, methods.getAPIRequest(Constant.METHOD_CATEGORY, 0, "", "", "", "", "", "", "", "", "", "", "", et_url.getText().toString(), null, null));
        loadAllCat.execute();
    }

    private void setNewsData() {
        et_title.setText(itemNews.getHeading());
        et_description.setText(itemNews.getDesc());
        tv_date.setText(itemNews.getDate());

        if (itemNews.getType().equals("image")) {
            spinner_type.setSelection(0, true);
        } else {
            spinner_type.setSelection(1, true);
            et_url.setText(itemNews.getVideoUrl());
        }

        Picasso.get().load(itemNews.getImage()).into(iv_image);

//        for (int i = 0; i < itemNews.getGalleryList().size(); i++) {
//            arrayList_item_gallery.add(new ItemGallery(itemNews.getGalleryList().get(i).getImage()));
//        }

        arrayList_item_gallery.addAll(itemNews.getGalleryList());

        if (arrayList_item_gallery.size() > 0) {
            adapterGallery = new AdapterGalleryEdit(UploadedNewsEditActivity.this, itemNews.getId(), arrayList_item_gallery, arrayList_file_gallery);
            rv_upload_gallery.setAdapter(adapterGallery);

            iv_upload_gallery.setVisibility(View.INVISIBLE);
        }
    }

    private void uploadNews() {
        File file = null;
        try {
            if (imageUri != null) {
                file = new File(methods.getTempUploadPath(imageUri));
            }

            for (int i = 0; i < arrayList_file_gallery.size(); i++) {
                String path = methods.getTempUploadPath(arrayList_file_gallery.get(i));
                if (!path.equals("")) {
                    arrayList_file.add(new File(path));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        LoadUpload loadUpload = new LoadUpload(new SuccessListener() {
            @Override
            public void onStart() {
                progress.show();
            }

            @Override
            public void onEnd(String success, String registerSuccess, String message) {
                if (success.equals("1")) {
                    if (registerSuccess.equals("1")) {

                        Constant.isNewsUpdated = true;

                        UploadedNewsEditActivity.this.finish();
                    } else {
                        Toast.makeText(UploadedNewsEditActivity.this, message, Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(UploadedNewsEditActivity.this, getResources().getString(R.string.server_error), Toast.LENGTH_LONG).show();
                }
                progress.dismiss();
            }
        }, methods.getAPIRequest(Constant.METHOD_EDIT_UPLOAD_NEWS, 0, et_title.getText().toString(), itemNews.getId(), et_description.getText().toString(), type, cat_id, tv_date.getText().toString(), "", "", "", "", sharedPref.getUserId(), et_url.getText().toString(), file, arrayList_file));
        loadUpload.execute();

    }

    private void pickImage() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, getResources().getString(R.string.select_image)), PICK_IMAGE_REQUEST);
    }

    private void pickMultipleImage() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, getResources().getString(R.string.select_image)), PICK_MULTIPLE_IMAGE_REQUEST);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {

            imageUri = data.getData();
            iv_image.setImageURI(imageUri);

        } else if (requestCode == PICK_MULTIPLE_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null) {
            if (data.getClipData() != null && data.getClipData().getItemCount() > 0) {
                for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                    arrayList_file_gallery.add(data.getClipData().getItemAt(i).getUri());
                    arrayList_item_gallery.add(new ItemGallery(data.getClipData().getItemAt(i).getUri()));
                }
            } else if (data.getData() != null) {
                Uri uri = data.getData();
                arrayList_file_gallery.add(uri);
                arrayList_item_gallery.add(new ItemGallery(uri));
            }

            if (adapterGallery == null) {
                adapterGallery = new AdapterGalleryEdit(UploadedNewsEditActivity.this, itemNews.getId(), arrayList_item_gallery, arrayList_file_gallery);
                rv_upload_gallery.setAdapter(adapterGallery);
            } else {
                adapterGallery.notifyDataSetChanged();
            }
            iv_upload_gallery.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    public void onDateSet(DatePickerDialog view, int year, int monthOfYear, int dayOfMonth) {
        tv_date.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);
    }
}