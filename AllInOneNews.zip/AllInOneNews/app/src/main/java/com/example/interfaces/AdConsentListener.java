package com.example.interfaces;

public interface AdConsentListener {
    void onConsentUpdate();
}
