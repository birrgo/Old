package com.example.interfaces;

import com.example.item.ItemComment;

import java.util.ArrayList;

public interface ClickListener {
    void onClick(int pos);
}