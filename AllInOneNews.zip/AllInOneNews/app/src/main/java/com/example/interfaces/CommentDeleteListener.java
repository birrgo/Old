package com.example.interfaces;

import com.example.item.ItemComment;

public interface CommentDeleteListener {
    void onStart();
    void onEnd(String success, String isDeleted, String message, ItemComment itemComment);
}