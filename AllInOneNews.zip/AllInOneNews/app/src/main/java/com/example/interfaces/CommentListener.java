package com.example.interfaces;

import com.example.item.ItemComment;
import com.example.item.ItemNews;

import java.util.ArrayList;

public interface CommentListener {
    void onStart();

    void onEnd(String success, ArrayList<ItemComment> arrayListComment);
}