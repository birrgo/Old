package com.example.interfaces;

import com.example.item.ItemCat;
import com.example.item.ItemNews;

import java.util.ArrayList;

public interface HomeListener {
    void onStart();
    void onEnd(String success, ArrayList<ItemNews> arrayListLatest, ArrayList<ItemNews> arrayListTrending, ArrayList<ItemNews> arrayListTop, ArrayList<ItemCat> arrayListCat);
}