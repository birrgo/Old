package com.example.interfaces;

import com.example.item.ItemCat;
import com.example.item.ItemNews;

import java.util.ArrayList;

public interface NewsListener {
    void onStart();

    void onEnd(String success, String verifyStatus, String message, ArrayList<ItemNews> arrayList, int totalNews);
}