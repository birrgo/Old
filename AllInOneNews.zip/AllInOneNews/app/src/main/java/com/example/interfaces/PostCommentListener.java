package com.example.interfaces;

import com.example.item.ItemComment;

public interface PostCommentListener {
    void onStart();
    void onEnd(String success, String isCommentPosted, String message, ItemComment itemComment);
}