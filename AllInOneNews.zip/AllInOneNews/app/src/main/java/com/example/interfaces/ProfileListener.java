package com.example.interfaces;

public interface ProfileListener {
    void onStart();
    void onEnd(String success, String isWorkSuccess, String message, String name, String email, String mobile, String profileImage, boolean isReporter);
}