package com.example.interfaces;

import com.example.item.ItemComment;
import com.example.item.ItemNews;

import java.util.ArrayList;

public interface SingleNewsListener {
    void onStart();

    void onEnd(String success, ItemNews itemNews, ArrayList<ItemComment> arrayListComments, ArrayList<ItemNews> arrayListRelated);
}