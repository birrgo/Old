package com.example.utils;

import android.content.Context;
import android.os.Bundle;

import com.google.ads.consent.ConsentInformation;
import com.google.ads.consent.ConsentStatus;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.ads.mediation.facebook.FacebookMediationAdapter;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

import androidx.annotation.NonNull;

public class AdManagerInterAdmob {
    static InterstitialAd interAd;
    private final Context ctx;

    public AdManagerInterAdmob(Context ctx) {
        this.ctx = ctx;
    }

    public void createAd() {
        Bundle extras = new Bundle();
        if (ConsentInformation.getInstance(ctx).getConsentStatus() == ConsentStatus.NON_PERSONALIZED) {
            extras.putString("npa", "1");
        }

        AdRequest.Builder adRequestBuilder = new AdRequest.Builder()
                .addNetworkExtrasBundle(AdMobAdapter.class, extras);
        if(Constant.interstitialAdType.equals(Constant.AD_TYPE_FACEBOOK)) {
            adRequestBuilder.addNetworkExtrasBundle(FacebookMediationAdapter.class, extras);
        }
        InterstitialAd.load(ctx, Constant.interstitialAdID, adRequestBuilder.build(), new InterstitialAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                interAd = interstitialAd;
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
            }
        });
    }

    public InterstitialAd getAd() {
        return interAd;
    }

    public static void setAd(InterstitialAd interstitialAd) {
        interAd = interstitialAd;
    }
}